// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept> // Required for standard exception classes
#include <string>    // Required for std::string

// First, let's define the custom exception class.
// It inherits from std::exception to be part of the standard exception hierarchy.
class MyCustomException : public std::exception
{
public:
    // Override the what() method to provide a custom error message.
    const char* what() const noexcept override
    {
        return "This is my custom exception!";
    }
};


bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    // Throwing a std::runtime_error as an example of a standard exception.
    throw std::runtime_error("A standard exception occurred in do_even_more_custom_application_logic()");

    // This part of the function will not be reached due to the exception.
    return true;
}

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        // Catch the standard exception, print a message, and continue execution.
        std::cout << "Caught a standard exception inside do_custom_application_logic: " << e.what() << std::endl;
    }


    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    std::cout << "Leaving Custom Application Logic." << std::endl;
    throw MyCustomException();

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0)
    {
        // std::invalid_argument is a suitable exception for this case.
        throw std::invalid_argument("Denominator cannot be zero.");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e)
    {
        // This handler specifically catches the divide-by-zero error.
        std::cout << "Error in do_division(): " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const MyCustomException& e)
    {
        // 1. Catches our specific custom exception first.
        std::cout << "Caught in main: " << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        // 2. Catches any other standard exceptions that might have been missed.
        std::cout << "Caught a general std::exception in main: " << e.what() << std::endl;
    }
    catch (...)
    {
        // 3. The catch-all handler for any other type of exception.
        std::cout << "Caught an unknown exception in main." << std::endl;
    }
}